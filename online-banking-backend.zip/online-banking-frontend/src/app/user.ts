export class User {
    constructor(public userid:number,
        public name:String,
        public email:String,
        public password:String,
        public address:String,
        public transactionpassword:String,
        public phno:number,
        public panno:number,
        



    ){}
}
