export class Deposit {
    constructor(
        public accountno:number,
        public balance:number){}
}
