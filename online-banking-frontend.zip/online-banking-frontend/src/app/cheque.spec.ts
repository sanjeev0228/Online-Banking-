import { Cheque } from './cheque';

describe('Cheque', () => {
  it('should create an instance', () => {
    expect(new Cheque()).toBeTruthy();
  });
});
