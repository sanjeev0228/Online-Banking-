export class Admin {
    constructor(public email:String,
                public password:String 

    ){}
}
